<?php require_once("head.php"); ?>
<?php require_once("navigation.php"); ?>
<?php require_once("header.php"); ?>
			<h2>Contribute</h2>
			<p>HexaMonkey is release under the GNU Public Licence v2 and all the code is available on GitHub:
			<p><a href="https://github.com/HexaMonkey/hexamonkey">https://github.com/HexaMonkey/hexamonkey</a></p>
			<p>The platform can be used to contribute to the project.</p> 
<?php require_once("footer.php"); ?>
