
			</div>
			<div id="footer">&copy; Copyright 2013 HexaMonkey - <a href="mailto:hexamonkey@hexamonkey.com">contact</a></div>
		</div>
	</body>
</html>
