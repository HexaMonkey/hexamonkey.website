		<div id="navigation">
			<div id="title">
				<a href="/"><img src="media/title.png"/></a>
			</div>
			<div id="navbar">
				<h1>Main</h1>
				<ul>
					<li><a href="/">About</a></li>
					<li><a href="contribute.php">Contribute</a></li>
				</ul>
				<h1>Download</h1>
				<ul>					
					<li><a href="download.php">HexaMonkey</a></li>
				</ul>
				<h1>Documentation</h1>
				<ul>
					<li><a href="hmdoc.php">HMscript</a></li>
					<li><a href="doc/">Developer</a></li>
				</ul>
			</div>
		</div>
