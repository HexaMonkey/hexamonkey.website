<!DOCTYPE html>
<html>
	<head>
		<title>HexaMonkey</title>
		<meta http-equiv="x-ua-compatible" content="IE=8" />
		<link href="body.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div id="page">
